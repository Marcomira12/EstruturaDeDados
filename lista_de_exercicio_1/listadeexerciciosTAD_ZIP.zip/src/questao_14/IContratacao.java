package questao_14;

public interface IContratacao {
	boolean adicionar();
	boolean alterar();
}
