package questao_6;

public interface IOperacao {
	boolean adicionar();
	boolean remover();
	boolean excluir();
	boolean atualizar();
}
