package questao_2;

public interface IEscola {
	boolean adicionar();
	boolean remover();
	boolean alterar();
	
}
