package questao_4;

public interface IOperacao {
	public boolean igualdade_dois_numeros(int numero_1,int  numero_2);
	public int somar(int numero_1,int  numero_2);
	public int multiplicar(int numero_1,int  numero_2);
	public int criar_racional(int numero_1,int  numero_2);
	
}
