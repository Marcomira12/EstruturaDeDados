package questao_10;

public interface IMusica {
	boolean adicionar();
	boolean remover();
	boolean lsitar();
}
