package questao_15;

public interface IFila {
	boolean adicionar();
	boolean remover();
	
}
