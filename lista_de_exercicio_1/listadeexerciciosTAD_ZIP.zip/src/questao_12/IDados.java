package questao_12;

public interface IDados {
	boolean adicionar();
	
	
}
