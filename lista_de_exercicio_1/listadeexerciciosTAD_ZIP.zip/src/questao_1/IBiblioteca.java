package questao_1;

public interface IBiblioteca {
	boolean adiconar();
	boolean remover();
	boolean alterar();
}
