package questao_16;

public interface IDiario {
	boolean adicionar();
	boolean remover();
	boolean alterar();
}
