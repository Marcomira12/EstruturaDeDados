package questao_8;

public interface IColecao {
	boolean adicionar();
	boolean remover();
	boolean alterar();
}
