package questao_11;

public interface IEstoque {
	boolean adicionar();
	boolean remover();
	boolean alterar();
}
