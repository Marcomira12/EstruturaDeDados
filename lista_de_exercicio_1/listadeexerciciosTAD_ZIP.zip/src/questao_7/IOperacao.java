package questao_7;

public interface IOperacao {
	boolean getNome(String nome);
	boolean getNumberTutor(int number);
	
	boolean getRaca(String raca);
	boolean getData(String data);
}
