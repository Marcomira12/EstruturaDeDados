package questao_9;

public interface ICozinha {
	boolean adicionar();
	boolean remover();
	boolean alterar();
}
