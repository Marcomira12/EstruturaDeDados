package questao_13;

public interface ICampeonato {
	boolean adicionar();
	boolean remover();
	boolean alterar();
}
