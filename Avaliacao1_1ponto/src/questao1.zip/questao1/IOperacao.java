package questao1;

public interface IOperacao {
	boolean adicionar();
	boolean remover();
	void listar();
	boolean alterar();
}
