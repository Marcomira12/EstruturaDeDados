package questao3;

public class Celula {
	private Musicas valor;
	private Celula proximo;
	
	
	public Musicas getValor() {
		return valor;
	}
	public void setValor(Musicas valor) {
		this.valor = valor;
	}
	public Celula getProximo() {
		return proximo;
	}
	public void setProximo(Celula proximo) {
		this.proximo = proximo;
	}
	
	
}
