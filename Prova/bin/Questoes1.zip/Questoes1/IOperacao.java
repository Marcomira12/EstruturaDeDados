package Questoes1;

public interface IOperacao {
	void adicionar(String nome, double nota);
	void listarSerie();
	void alterarSerie(String nome);
	boolean excluuir(String nome);
	
}
