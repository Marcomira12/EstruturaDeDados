package questao3;

public class Celula {
	private Celula proximo;
	private Livros valor;
	
	
	public Celula getProximo() {
		return proximo;
	}
	public void setProximo(Celula proximo) {
		this.proximo = proximo;
	}
	public Livros getValor() {
		return valor;
	}
	public void setValor(Livros valor) {
		this.valor = valor;
	}
	
	
}
