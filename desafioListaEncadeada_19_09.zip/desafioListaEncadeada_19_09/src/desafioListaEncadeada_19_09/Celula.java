package desafioListaEncadeada_19_09;

public class Celula {
	private Viagens valor;
	private Celula proximo;
	
	
	public Viagens getValor() {
		return valor;
	}
	public void setValor(Viagens valor) {
		this.valor = valor;
	}
	public Celula getProximo() {
		return proximo;
	}
	public void setProximo(Celula proximo) {
		this.proximo = proximo;
	}
	
	
}
