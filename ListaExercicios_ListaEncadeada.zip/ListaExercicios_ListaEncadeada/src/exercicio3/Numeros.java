package exercicio3;

public class Numeros {
	private int number;

	public Numeros(int number) {
		
		this.number = number;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	
}
