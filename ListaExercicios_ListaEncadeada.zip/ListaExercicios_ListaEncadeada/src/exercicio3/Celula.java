package exercicio3;

public class Celula {
	private Numeros valor;
	private Celula proximo;
	public Numeros getValor() {
		return valor;
	}
	public void setValor(Numeros valor) {
		this.valor = valor;
	}
	public Celula getProximo() {
		return proximo;
	}
	public void setProximo(Celula proximo) {
		this.proximo = proximo;
	}
	
}
