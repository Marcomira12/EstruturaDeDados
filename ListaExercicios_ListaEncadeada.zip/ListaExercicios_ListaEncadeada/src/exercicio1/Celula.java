package exercicio1;

public class Celula {
	private Professores valor;
	private Celula proximo;
	
	
	
	public Professores getValor() {
		return valor;
	}
	public void setValor(Professores valor) {
		this.valor = valor;
	}
	public Celula getProximo() {
		return proximo;
	}
	public void setProximo(Celula proximo) {
		this.proximo = proximo;
	}
	
	
}
