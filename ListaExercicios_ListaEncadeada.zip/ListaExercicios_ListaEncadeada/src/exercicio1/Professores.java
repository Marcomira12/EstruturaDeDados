package exercicio1;

public class Professores {
	private String name;

	public Professores(String name) {
		
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String toString() {
	    return name;
	}
}
