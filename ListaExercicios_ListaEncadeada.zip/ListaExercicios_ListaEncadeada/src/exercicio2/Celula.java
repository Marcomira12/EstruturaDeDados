package exercicio2;

public class Celula {
	private Matricula valor;
	private Celula proximo;
	public Matricula getValor() {
		return valor;
	}
	public void setValor(Matricula valor) {
		this.valor = valor;
	}
	public Celula getProximo() {
		return proximo;
	}
	public void setProximo(Celula proximo) {
		this.proximo = proximo;
	}
	
	
	
}
