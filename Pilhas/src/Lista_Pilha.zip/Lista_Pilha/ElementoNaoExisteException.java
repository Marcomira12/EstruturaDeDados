package Lista_Pilha;

public class ElementoNaoExisteException extends RuntimeException {

	public ElementoNaoExisteException(String err) {
		super(err);
	}

	

}
