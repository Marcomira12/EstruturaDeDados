package Lista_Pilha;

public class PilhaVaziaException extends Exception {

	public PilhaVaziaException(String err) {
		super(err);
	}
	
}
